package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity3 extends AppCompatActivity {
    TextView tvName, tvNum, tvStatus, tvDate, tvBack;
    CircleImageView civProfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        tvBack = findViewById(R.id.tvBack);
        tvNum = findViewById(R.id.tvNum);
        tvStatus = findViewById(R.id.tvStatus);
        tvDate = findViewById(R.id.tvDate);
        civProfil = findViewById(R.id.civProfil);
        tvName = findViewById(R.id.tvName);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String number = intent.getStringExtra("number");
        String status = intent.getStringExtra("status");
        String date = intent.getStringExtra("date");
        int profil = intent.getIntExtra("profil",0);

        tvName.setText(name);
        tvNum.setText(number);
        tvStatus.setText(status);
        tvDate.setText(date);
        civProfil.setImageResource(profil);

        civProfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                intent.putExtra("name", name);
                intent.putExtra("number", number);
                intent.putExtra("status", status);
                intent.putExtra("date", date);
                intent.putExtra("profil", profil);
                startActivity(intent);
            }
        });
        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
                intent.putExtra("name", name);
                intent.putExtra("number", number);
                intent.putExtra("status", status);
                intent.putExtra("date", date);
                intent.putExtra("profil", profil);
                startActivity(intent);
            }
        });
    }
}