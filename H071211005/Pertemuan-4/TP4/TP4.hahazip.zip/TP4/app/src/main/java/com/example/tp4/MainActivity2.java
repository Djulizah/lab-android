package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity2 extends AppCompatActivity {

    TextView tvBack, tvName;
    CircleImageView civProfil;
    RecyclerView rvRoom;
//    private ArrayList<chat> chatlist = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tvBack = findViewById(R.id.tvBack);
        tvName = findViewById(R.id.tvName);
        civProfil = findViewById(R.id.civProfil);
        rvRoom= findViewById(R.id.rvRoom);
        rvRoom.setHasFixedSize(true);
        rvRoom.setLayoutManager(new LinearLayoutManager(this));

        Intent intent = getIntent();
        Chat chat = intent.getParcelableExtra("chat");
        tvName.setText(chat.getTvName());
        civProfil.setImageResource(chat.getIm1());

        Adapter2 adapter = new Adapter2(chat.getListMsg());
        rvRoom.setAdapter(adapter);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,MainActivity3.class);
                startActivity(intent);
            }
        });
    }

}