package com.example.tp4;

import java.util.ArrayList;

public class DataSource {
    static String [][] mess1 = {
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
    };
    static String [][] mess2 = {
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
            {"halo", "hai juga", "hai", "hai juga",},
    };
    static String [][] time1 = {
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
    };
    static String [][] time2 = {
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
            {"23.45", "12.34", "23.45", "12.34",},
    };


    public static ArrayList<Chat> getListchat() {
        ArrayList<ArrayList<Room>> listRoom = new ArrayList<>();
        for (int i=0; i<10;i++) {
            ArrayList<Room> temp = new ArrayList<>();
            for(int j=0; j<4;j++){
                Room room = new Room(mess1[i][j],time1[i][j],mess2[i][j],time2[i][j]);
                temp.add(room);
            }
            listRoom.add(temp);
        }
        //membuat array list
        ArrayList<Chat> userlist = new ArrayList<>();
        // menambahkan objek food
        userlist.add(new Chat("Firaa",  "01.44", R.drawable.im1, "+62 123 123 1234", "Busy", "April 12,2023" ,listRoom.get(0)));
        userlist.add(new Chat("Ohh Firaa",  "02.46", R.drawable.im2, "+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(1)));
        userlist.add(new Chat("Fira Cans",  "03.46", R.drawable.im3, "+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(2) ));
        userlist.add(new Chat("Raafi",  "04.46", R.drawable.im4,"+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(3)  ));
        userlist.add(new Chat("Inzani",  "05.46", R.drawable.im5, "+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(4) ));
        userlist.add(new Chat("Mage",  "06.46", R.drawable.img10, "+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(5) ));
        userlist.add(new Chat("Andi",  "17.46", R.drawable.img7, "+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(6) ));
        userlist.add(new Chat("Saputra",  "18.46", R.drawable.imglo, "+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(7) ));
        userlist.add(new Chat("Maghfirah",  "19.46", R.drawable.imgpe, "+62 123 123 1234", "Busy", "April 12,2023" ,listRoom.get(8)));
        userlist.add(new Chat("Zani",  "23.46", R.drawable.tanjiro, "+62 123 123 1234", "Busy", "April 12,2023",listRoom.get(9) ));
        return userlist;
    }
}
