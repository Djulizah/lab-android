package com.example.tp4;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Room implements Parcelable {
    private String tvMess;
    private String tvDate;

    public Room(String tvMess, String tvDate, String tvmess2, String tvDate2) {
        this.tvMess = tvMess;
        this.tvDate = tvDate;
        this.tvmess2 = tvmess2;
        this.tvDate2 = tvDate2;
    }

    private String tvmess2;
    private String tvDate2;

    public Room(String msg, String time) {
    }

    public String getTvMess() {
        return tvMess;
    }

    public void setTvMess(String tvMess) {
        this.tvMess = tvMess;
    }

    public String getTvmess2() {
        return tvmess2;
    }

    public void setTvmess2(String tvmess2) {
        this.tvmess2 = tvmess2;
    }

    public String getTvDate() {
        return tvDate;
    }

    public void setTvDate(String tvDate) {
        this.tvDate = tvDate;
    }

    public String getTvDate2() {
        return tvDate2;
    }

    public void setTvDate2(String tvDate2) {
        this.tvDate2 = tvDate2;
    }

    protected Room(Parcel in) {
        tvMess = in.readString();
        tvmess2 = in.readString();
        tvDate = in.readString();
        tvDate2 = in.readString();
    }

    public static final Creator<Room> CREATOR = new Creator<Room>() {
        @Override
        public Room createFromParcel(Parcel in) {
            return new Room(in);
        }

        @Override
        public Room[] newArray(int size) {
            return new Room[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(tvMess);
        parcel.writeString(tvmess2);
        parcel.writeString(tvDate);
        parcel.writeString(tvDate2);
    }
}
