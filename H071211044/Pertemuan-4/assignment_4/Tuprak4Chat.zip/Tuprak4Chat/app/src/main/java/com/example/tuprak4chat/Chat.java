package com.example.tuprak4chat;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Chat implements Parcelable {

    private String name;
    private String chat;
    private String time;
    private String notelp;
    private String status;
    private String info;
    private int photo;

    public Chat(String name, String chat, String time, int photo) {
    }

    public Chat(String s, String haloo_cantikk, String s1, int photo, String s2, String busy, String s3, ArrayList<RoomChat> roomChats) {
    }

    protected Chat(Parcel in) {
        name = in.readString();
        chat = in.readString();
        time = in.readString();
        notelp = in.readString();
        status = in.readString();
        info = in.readString();
        photo = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(chat);
        dest.writeString(time);
        dest.writeString(notelp);
        dest.writeString(status);
        dest.writeString(info);
        dest.writeInt(photo);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Chat> CREATOR = new Creator<Chat>() {
        @Override
        public Chat createFromParcel(Parcel in) {
            return new Chat(in);
        }

        @Override
        public Chat[] newArray(int size) {
            return new Chat[size];
        }
    };

    public String getNotelp() {
        return notelp;
    }

    public void setNotelp(String notelp) {
        this.notelp = notelp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Chat(String name, String chat, String time, String notelp, String status, String info, int photo) {
        this.name = name;
        this.chat = chat;
        this.time = time;
        this.notelp = notelp;
        this.status = status;
        this.info = info;
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getChat() {
        return chat;
    }

    public void setChat(String chat) {
        this.chat = chat;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }
}
