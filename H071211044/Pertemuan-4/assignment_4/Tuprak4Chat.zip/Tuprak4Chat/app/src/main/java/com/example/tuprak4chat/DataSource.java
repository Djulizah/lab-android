package com.example.tuprak4chat;

import java.util.ArrayList;
import java.util.Arrays;

public class DataSource {

    static String [][] message1 = {
            {" haloww cantikk", "helloww", "haii", "hai jugakk",},
            {" haloww cantikk", "helloww", "haii", "hai jugakk",},
            {" haloww cantikk", "helloww", "haii", "hai jugakk",},
            {" haloww cantikk", "helloww", "haii", "hai jugakk",},
            {" haloww cantikk", "helloww", "haii", "hai jugakk",},
            {" haloww cantikk", "helloww", "haii", "hai jugakk",},
            {" haloww cantikk", "helloww", "haii", "hai jugakk",},
    };

    static String [][] message2 = {
            {" heyy guys", "iyaaa", "haloo", "iyaaa",},
            {" heyy guys", "iyaaa", "haloo", "iyaaa",},
            {" heyy guys", "iyaaa", "haloo", "iyaaa",},
            {" heyy guys", "iyaaa", "haloo", "iyaaa",},
            {" heyy guys", "iyaaa", "haloo", "iyaaa",},
            {" heyy guys", "iyaaa", "haloo", "iyaaa",},
            {" heyy guys", "iyaaa", "haloo", "iyaaa",},
    };

    static String [][] time1 = {
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
    };

    static String [][] time2 = {
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
            {"15.25", "20.15", "15.25", "20.15",},
    };

    public static ArrayList<Chat> getListchat() {
        ArrayList<ArrayList<RoomChat>> listRoomChat = new ArrayList<>();
        for (int i=0; i<10;i++) {
            ArrayList<RoomChat> temp = new ArrayList<>();
            for(int j=0; j<4;j++){
                RoomChat roomChat = new RoomChat(message1[i][j],time1[i][j],message2[i][j],time2[i][j]);
                temp.add(roomChat);
            }
            listRoomChat.add(temp);
        }

    ArrayList<Chat> chats = new ArrayList<>();

        new Chat("Doi 1", "haloo cantikk", "11.31", R.drawable.baale, "+62 111 123 3344", "Busy", "Februari 01,2023" ,listRoomChat.get(0));
        new Chat("Rony", "mowningggg", "00.31" , R.drawable.rony, "+62 123 222 1111", "Available", "Februari 01,2023" ,listRoomChat.get(1));
        new Chat("Paul", "iyaa cantikk", "05.13" , R.drawable.paull, "+62 444 555 6678", "Tidur", "Februari 01,2023" ,listRoomChat.get(2));
        new Chat("Doi 2", "ak otw yaaa", "12.45" , R.drawable.angga, "+62 333 123 5678", "Jangan ganggu", "Februari 01,2023" ,listRoomChat.get(3));
        new Chat("Doi 3", "makan yukk", "09.31" , R.drawable.azmi, "+62 555 111 1221", "Busy", "Februari 01,2023" ,listRoomChat.get(4));
        new Chat("Doi 5", "yokklahh", "23.39" , R.drawable.rizkyn, "+62 666 121 3333", "Ada", "Februari 01,2023" ,listRoomChat.get(5));
        new Chat("Doi 4", "okeyy cantikk", "15.20" , R.drawable.cipung, "+62 777 888 9940", "Gila", "Februari 01,2023" ,listRoomChat.get(7));
        return chats;
    }
}
