package com.example.tuprak4chat;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.imageview.ShapeableImageView;

public class MainActivity3 extends AppCompatActivity {

TextView tvBack, tvNama, tvStatus, tvInfo, tvNotelp;
ShapeableImageView profile;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiledetail);

        tvBack = findViewById(R.id.tv_back);
        tvNama = findViewById(R.id.nama);
        tvStatus = findViewById(R.id.Status);
        tvInfo = findViewById(R.id.Info);
        tvNotelp = findViewById(R.id.notelp);
        profile = findViewById(R.id.profile);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String number = intent.getStringExtra("number");
        String status = intent.getStringExtra("status");
        String date = intent.getStringExtra("date");
        int profil = intent.getIntExtra("profil", 0);

        tvNama.setText(name);
        tvStatus.setText(status);
        tvNotelp.setText(number);
        tvInfo.setText(date);
        profile.setImageResource(profil);

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                    intent.putExtra("name", name);
                    intent.putExtra("number", number);
                    intent.putExtra("status", status);
                    intent.putExtra("date", date);
                    intent.putExtra("profil", profil);
                    startActivity(intent);
                }
            });
        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
                intent.putExtra("name", name);
                intent.putExtra("number", number);
                intent.putExtra("status", status);
                intent.putExtra("date", date);
                intent.putExtra("profil", profil);
                startActivity(intent);
            }
        });
    }
}
