package com.example.tuprak4chat;

import android.os.Parcel;
import android.os.Parcelable;

public class RoomChat implements Parcelable {
    protected RoomChat(Parcel in) {
        textchat_a = in.readString();
        textchat_b = in.readString();
        timea = in.readString();
        timeb = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(textchat_a);
        dest.writeString(textchat_b);
        dest.writeString(timea);
        dest.writeString(timeb);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<RoomChat> CREATOR = new Creator<RoomChat>() {
        @Override
        public RoomChat createFromParcel(Parcel in) {
            return new RoomChat(in);
        }

        @Override
        public RoomChat[] newArray(int size) {
            return new RoomChat[size];
        }
    };

    public String getTextchat_a() {
        return textchat_a;
    }

    public void setTextchat_a(String textchat_a) {
        this.textchat_a = textchat_a;
    }

    public String getTextchat_b() {
        return textchat_b;
    }

    public void setTextchat_b(String textchat_b) {
        this.textchat_b = textchat_b;
    }

    public String getTimea() {
        return timea;
    }

    public void setTimea(String timea) {
        this.timea = timea;
    }

    public String getTimeb() {
        return timeb;
    }

    public void setTimeb(String timeb) {
        this.timeb = timeb;
    }

    public RoomChat(String textchat_a, String textchat_b, String timea, String timeb) {
        this.textchat_a = textchat_a;
        this.textchat_b = textchat_b;
        this.timea = timea;
        this.timeb = timeb;
    }

    private String textchat_a, textchat_b, timea,timeb;
}
