package com.example.tuprak4chat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    RelativeLayout profileinfo;
    ShapeableImageView profil;
    TextView name, tvback;
    RecyclerView rv_roomchat;

//    private ArrayList<ModelRoomChat> data = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        profileinfo = findViewById(R.id.profile_info);
        profil = findViewById(R.id.profile);
        name = findViewById(R.id.nama);
        tvback = findViewById(R.id.tv_back);

        rv_roomchat = findViewById(R.id.rvRoomChat);
        rv_roomchat.setHasFixedSize(true);
        rv_roomchat.setLayoutManager(new LinearLayoutManager(this));


        Intent intent = getIntent();
        Chat chat = intent.getParcelableExtra("chat");
        name.setText(chat.getName());
        profil.setImageResource(chat.getPhoto());

         RoomChatAdapter ChatAdapter = new RoomChatAdapter(chat.getChat());
         rv_roomchat.setAdapter(ChatAdapter);

         tvback.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent intent = new Intent(MainActivity2.this,MainActivity.class);
                 startActivity(intent);
             }
         });

        }
    }