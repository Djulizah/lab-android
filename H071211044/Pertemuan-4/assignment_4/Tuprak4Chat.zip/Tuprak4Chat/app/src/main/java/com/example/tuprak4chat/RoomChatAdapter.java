package com.example.tuprak4chat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RoomChatAdapter extends RecyclerView.Adapter<RoomChatAdapter.RoomChatHolder> {
    private final ArrayList<RoomChat> RoomCht;

    public RoomChatAdapter(ArrayList<RoomChat> list){
        this.RoomCht = list;
    }

    @NonNull
    @Override
    public RoomChatAdapter.RoomChatHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View roomview = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_bubblechat,parent, false);
        RoomChatHolder roomChatHolder = new RoomChatHolder(roomview);
        return roomChatHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RoomChatHolder holder, int position) {
        RoomChat roomCht = RoomCht.get(position);
        holder.setData(roomCht);
    }

    @Override
    public int getItemCount() {
        return RoomCht.size();
    }

    public class RoomChatHolder extends RecyclerView.ViewHolder {
        private TextView textchat_a, timea, textchat_b,timeb ;
        public RoomChatHolder(@NonNull View itemView) {
            super(itemView);
            textchat_a = itemView.findViewById(R.id.textchata);
            textchat_b = itemView.findViewById(R.id.textchatb);
            timea = itemView.findViewById(R.id.timea);
            timeb = itemView.findViewById(R.id.timeb);
        }
        public void setData (RoomChat RoomCht){
            textchat_a.setText(RoomCht.getTextchat_a());
            textchat_b.setText(RoomCht.getTextchat_b());
            timea.setText(RoomCht.getTimea());
            timeb.setText(RoomCht.getTimeb());
        }
    }
}
