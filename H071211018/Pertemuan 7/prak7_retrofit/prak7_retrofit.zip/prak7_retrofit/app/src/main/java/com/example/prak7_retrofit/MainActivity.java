package com.example.prak7_retrofit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv_user;
    private ArrayList<UserResponse> data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv_user = findViewById(R.id.rv_user);

        Call<DataResponse> client = ApiConfig.getApiService().getUser("20");
        client.enqueue(new Callback<DataResponse>() {
            @Override
            public void onResponse(Call<DataResponse> call, Response<DataResponse>
                    response) {
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        ArrayList<UserResponse> userResponse = response.body().getData();
                        UserAdapter adkhCard = new UserAdapter(userResponse);
                        rv_user.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                        rv_user.setAdapter(adkhCard);
                        System.out.println(adkhCard.getItemCount());
                    }
                    } else {
                        if (response.body() != null) {
                            Log.e("MainActivity", "onFailure1: " + response.message());
                        }
                    }
                }
            @Override
            public void onFailure(Call<DataResponse> call, Throwable t) {
                Log.e("MainActivity", "onFailure: " + t.getMessage());
            }
        });
    }
}
